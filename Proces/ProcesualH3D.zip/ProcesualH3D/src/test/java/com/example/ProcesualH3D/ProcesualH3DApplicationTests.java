package com.example.ProcesualH3D;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcesualH3DApplicationTests {

	@Test
	void contextLoads() {
	}

}
