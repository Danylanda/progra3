package com.example.ProcesualH3D;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcesualH3DApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcesualH3DApplication.class, args);
	}

}
